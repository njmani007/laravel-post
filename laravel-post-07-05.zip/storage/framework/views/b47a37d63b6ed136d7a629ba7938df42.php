<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="row align-items-center mb-3">
            <div class="col-md-6">
                <h3>All Posts</h3>
            </div>
            <div class="col-md-6 d-flex justify-content-end">
                <a href="<?php echo e(route('post.create')); ?>" class="btn btn-warning">Add Post</a>
            </div>
        </div>

        <?php if($posts->isEmpty()): ?>
            <p>No posts available.</p>
        <?php else: ?>
            <div class="row">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $user = Auth::user();
                        $userLiked = $post
                            ->likes()
                            ->where('user_id', $user->id)
                            ->exists();
                    ?>
                    <div class="col-md-4">
                        <div class="card mb-4">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($post->title); ?></h5>
                                <p class="card-text"><?php echo e(\Illuminate\Support\Str::limit($post->description, 100)); ?></p>
                                <div class="d-flex justify-content-between">
                                    <div style="display: flex; gap: 3px; align-items: center;">
                                        <i class="<?php echo e($userLiked ? 'fa-solid' : 'fa-regular'); ?> fa-heart"
                                            style="cursor: pointer;" onclick="toggleLike(<?php echo e($post->id); ?>, this)">
                                        </i>
                                        <span class="like-count"><?php echo e($post->likes()->count()); ?></span> <!-- Like count -->
                                    </div>
                                    <button class="btn btn-danger" onclick="deletePost(<?php echo e($post->id); ?>)">Delete</button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.js"></script>

<script>
    function toggleLike(postId, element) {
        // alert(postId)
        const isLiked = $(element).hasClass("fa-solid");
        const likeCountSpan = $(element).siblings(".like-count");
        const currentCount = parseInt(likeCountSpan.text());
        const method = isLiked ? 'DELETE' : 'POST';
        $.ajax({
            url: `/posts/${postId}/like`,
            method: method,
            data: {
                _token: '<?php echo e(csrf_token()); ?>',
            },
            success: function(response) {
                if (method === 'POST') {
                    $(element).removeClass("fa-regular").addClass("fa-solid");
                    likeCountSpan.text(currentCount + 1);
                    // toastr.success("Post liked!");
                } else {
                    $(element).removeClass("fa-solid").addClass("fa-regular");
                    likeCountSpan.text(currentCount - 1);
                    // toastr.success("Post unliked!");
                }
            },
            error: function(xhr, status, error) {
                toastr.error("An error occurred. Please try again.");
            },
        });
    }

    function deletePost(postId) {
        if (confirm("Are you sure you want to delete this post?")) {
            $.ajax({
                url: `/posts/${postId}`,
                method: 'POST',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                },
                success: function(response) {
                    toastr.success("Post deleted successfully");
                    setTimeout(() => location.reload(), 1000);
                },
                error: function() {
                    toastr.error("An error occurred. Please try again.");
                },
            });
        }
    }
</script>

<?php echo $__env->make('auth.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-post\resources\views/post/index.blade.php ENDPATH**/ ?>